
  function displayMessage() {
    alert(
      "Mutual fund investments are subject to market risks. Please read all scheme related documents carefully before investing. Past performance of the schemes is neither an indicator nor a guarantee of future performance."
    );
  }
  

  